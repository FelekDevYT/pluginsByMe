package net.felsstudio.readyrtp.Commands;

import net.felsstudio.readyrtp.RTP.RTP;
import net.felsstudio.readyrtp.ReadyRTP;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public class RandomTeleportationPlayerCommand implements CommandExecutor {

    private final ReadyRTP plugin;

    public RandomTeleportationPlayerCommand(ReadyRTP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command com, String label, String[] args) {

        if(!(sender instanceof Player)) {
            sender.sendMessage("You must be a player to use this command.");
            return false;
        }

        //configs
        List<Integer> cords = plugin.getConfig().getIntegerList("cords");

        Player p = (Player) sender;

        try {
            Thread.sleep((plugin.getConfig().getInt("cooldown"))* 1000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        List<Integer> c = RTP.RandomTeleportationPlayer(p,p.getWorld(),cords.get(0),cords.get(1),cords.get(2),cords.get(3));

        p.sendMessage(ChatColor.GREEN+"You teleported to : "+c.get(0)+","+c.get(1)+","+c.get(2));

        return true;
    }
}
