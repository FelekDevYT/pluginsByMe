package net.felsstudio.readyrtp.Commands;

import net.felsstudio.readyrtp.ReadyRTP;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;

public class setDefaultConfigsCommand implements CommandExecutor {

    private final ReadyRTP plugin;

    public setDefaultConfigsCommand(ReadyRTP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command com, String label, String[] args) {

        plugin.getConfig().set("cooldown", 5); //cooldown in seconds

        List<Integer> coords = new ArrayList<Integer>();//more in config.yml
        coords.add(0);
        coords.add(1000);
        coords.add(0);
        coords.add(1000);

        plugin.getConfig().set("coords",coords);

        plugin.saveConfig();

        sender.sendMessage(ChatColor.GREEN+"Configs of ReadyRTP has been set to defaults!");

        plugin.getLogger().info("Configs of ReadyRTP has been set to defaults!");

        return true;
    }
}
