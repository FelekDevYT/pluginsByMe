package net.felsstudio.readyrtp;

import net.felsstudio.readyrtp.Commands.RandomTeleportationPlayerCommand;
import net.felsstudio.readyrtp.Commands.setDefaultConfigsCommand;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;

public final class ReadyRTP extends JavaPlugin {

    @Override
    public void onEnable() {

        getCommand("setDefaultConfigs").setExecutor(new setDefaultConfigsCommand(this));

        saveDefaultConfig();

        getCommand("rtp").setExecutor(new RandomTeleportationPlayerCommand(this));

        getLogger().info("ReadyRTP plugin enabled");

    }

    @Override
    public void onDisable() {
        getLogger().info("ReadyRTP plugin disabled");
    }
}
