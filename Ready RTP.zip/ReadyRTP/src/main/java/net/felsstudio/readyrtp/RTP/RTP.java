package net.felsstudio.readyrtp.RTP;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.checkerframework.checker.units.qual.A;

import java.util.ArrayList;
import java.util.List;

public class RTP {

    private static int random(int min, int max){

        max-= min;
        return (int) (Math.random()* ++max) + min;

    }

    public static List<Integer> RandomTeleportationPlayer(Player player, World world, int minX, int maxX, int minZ, int maxZ){

        int x = random(minX,maxX);
        int z = random(minZ,maxZ);
        int y = world.getHighestBlockYAt(x, z) + 1;

        Location currentLocation = new Location(world, x, y, z);

        player.teleport(currentLocation);

        List<Integer> cords = new ArrayList<>();
        cords.add(x);
        cords.add(y);
        cords.add(z);

        return cords;

    }

}
